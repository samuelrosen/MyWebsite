function sq_diff_sum = sq_diff_sum(cdens,ret,obs,riskfree,vweight,theta_grid)
% Compute the sum of squared differences between the cumulative densities
% from option prices (cdens) and the cumulative densities based on stock
% returns estimated for a specified density (theta_dist) and a related set 
% of parameter values (theta_grid)

    % repeat ret and cdens vectors to match dim of theta_grid
    repmat_ret   = repmat(ret,[1,size(theta_grid,2)]);
    repmat_cdens = repmat(cdens,[1,size(theta_grid,2)]);
        
        % repeat grid values for each parameter to match repmat_ret size
        repmat_vol    = repmat(theta_grid(1,:),[obs,1]);
        repmat_nu     = repmat(theta_grid(2,:),[obs,1]);
        repmat_lambda = repmat(theta_grid(3,:),[obs,1]);

        % standardize the return vector to encorce martingale condition
        std_ret_vect=(repmat_ret-riskfree)./repmat_vol;

        % compute squared residuals 
        sq_diff_sum = (vweight')*(repmat_cdens - skewt_cdf_vec(std_ret_vect, repmat_nu, repmat_lambda)).^2;        

