% Estimate firm-specific RNDs using the skew-t distribution with options 
% and CDS data as described in:
%   Sirio Aramonte, Mohammad R. Jahan-Parvar, Samuel Rosen, John W. Schindler 
%   (2021). Firm-Specific Risk-Neutral Distributions with Options and CDS.
%   Management Science. https://doi.org/10.1287/mnsc.2021.4170

% This code produces an output data file (results_table.xlsx) and figure 
% files (figure_rnd_loop_group?.png) for the example data in 
% example_input_data.csv. A user could adapt this code for their
% purposes by creating their own input data csv file in the same format as
% example_input_data.csv and then importing it instead. This code is
% already set up to loop through a set of firm-date observations and it
% requires that the other Matlab functions (e.g., skewt_cdf_vec) are in the 
% same directory.

% Input variables required:
% strike: strike price of the option
% IV: (volume-weighted) implied volatility
% volume: log volume (associated with the weighted implied volatility)
% spread_5y: 5-year CDS spread
% recovery: recovery rate
% offset: time to the nearest payment date (in years)
% threshold: default threshold (log return over 3-months)
% rf90: annualized riskless rate closest to 90 days
% rf5yos: annualized riskless rate closest to 5 years plus time to the nearest payment date
% stock_price: stock price
% weight_cds: weight assigned to the CDS-implied cumulative probability in estimation
% weight_opt_nocds: weight assigned to the option-implied cumulative probability in estimation when there is no CDS
% weight_opt_cds: weight assigned to the option-implied cumulative probability in estimation when there is CDS
% group: id variable, which identifies a date/permno combination
% datenum: the number of date in Stata
% permno: permanent security identification number from CRSP

clearvars
clc;
close ALL;

% import data
T = readtable('example_input_data.csv');
data=table2array(T);
cds_flag=1; % cds is included

% id variable
group=data(:,14);
starting=1;
ending=max(group);

% create results matrix
results_matrix = nan(ending-starting+1, 9); 
results_matrix(:,1) = [starting:ending]';

% iterate over the group id
time_start = tic;
for loop_group = starting:ending  
    
    disp(strcat({'starting loop group '},num2str(loop_group)));
    
    clearvars -except results_matrix loop_group starting ending data group cds_flag time_start
    
    % data for the given loop group
    vi = find(group==loop_group);
    loop_group_data = data(vi,:);  
    strike=loop_group_data(:,1);
    IV=loop_group_data(:,2);
    volume=loop_group_data(:,3);
    spread_5y=loop_group_data(1,4);
    recovery=loop_group_data(1,5);
    offset=loop_group_data(1,6);
    threshold=loop_group_data(1,7);
    rf90=loop_group_data(:,8);   
    rf5yos=loop_group_data(1,9);
    stock_price=loop_group_data(:,10);
    weight_cds=loop_group_data(1,11);
    weight_opt_nocds=loop_group_data(:,12);
    weight_opt_cds=loop_group_data(:,13);
    % item 14, group, is assigned above
    datenum=loop_group_data(1,15);
    permno=loop_group_data(1,16);
  
    spread=spread_5y;
 
    % compute CDS-implied default probability over 3-months
   try
        spread=@(L) ( (1-recovery)*( ...
    exp(-rf5yos*offset)*(exp(-L*0)-exp(-L*offset)) + exp(-rf5yos*(0.25+offset))*(exp(-L*(0+offset))-exp(-L*(0.25+offset))) + exp(-rf5yos*(0.50+offset))*(exp(-L*(0.25+offset))-exp(-L*(0.50+offset))) + exp(-rf5yos*(0.75+offset))*(exp(-L*(0.50+offset))-exp(-L*(0.75+offset))) + exp(-rf5yos*(1+offset))*(exp(-L*(0.75+offset))-exp(-L*(1+offset)))+ ...    
                                                     exp(-rf5yos*(1.25+offset))*(exp(-L*(1+offset))-exp(-L*(1.25+offset))) + exp(-rf5yos*(1.50+offset))*(exp(-L*(1.25+offset))-exp(-L*(1.50+offset))) + exp(-rf5yos*(1.75+offset))*(exp(-L*(1.50+offset))-exp(-L*(1.75+offset))) + exp(-rf5yos*(2+offset))*(exp(-L*(1.75+offset))-exp(-L*(2+offset)))+ ...
                                                     exp(-rf5yos*(2.25+offset))*(exp(-L*(2+offset))-exp(-L*(2.25+offset))) + exp(-rf5yos*(2.50+offset))*(exp(-L*(2.25+offset))-exp(-L*(2.50+offset))) + exp(-rf5yos*(2.75+offset))*(exp(-L*(2.50+offset))-exp(-L*(2.75+offset))) + exp(-rf5yos*(3+offset))*(exp(-L*(2.75+offset))-exp(-L*(3+offset)))+ ...
                                                     exp(-rf5yos*(3.25+offset))*(exp(-L*(3+offset))-exp(-L*(3.25+offset))) + exp(-rf5yos*(3.50+offset))*(exp(-L*(3.25+offset))-exp(-L*(3.50+offset))) + exp(-rf5yos*(3.75+offset))*(exp(-L*(3.50+offset))-exp(-L*(3.75+offset))) + exp(-rf5yos*(4+offset))*(exp(-L*(3.75+offset))-exp(-L*(4+offset)))+ ...
                                                     exp(-rf5yos*(4.25+offset))*(exp(-L*(4+offset))-exp(-L*(4.25+offset))) + exp(-rf5yos*(4.50+offset))*(exp(-L*(4.25+offset))-exp(-L*(4.50+offset))) + exp(-rf5yos*(4.75+offset))*(exp(-L*(4.50+offset))-exp(-L*(4.75+offset))) + exp(-rf5yos*(5+offset))*(exp(-L*(4.75+offset))-exp(-L*(5+offset)))  ...
                                    ) ...
            /(  ...
          offset*exp(-L* 0.00        )*(exp(-L*offset)  +L^-1-exp(-L*offset)*(offset+L^-1))*exp(-rf5yos*offset       ) + ...
            0.25*exp(-L*(0.00+offset))*(exp(-L*0.25  )  +L^-1-exp(-L*0.25  )*(0.25  +L^-1))*exp(-rf5yos*(0.25+offset)) + ...
            0.25*exp(-L*(0.25+offset))*(exp(-L*0.25  )  +L^-1-exp(-L*0.25  )*(0.25  +L^-1))*exp(-rf5yos*(0.50+offset)) + ...
            0.25*exp(-L*(0.50+offset))*(exp(-L*0.25  )  +L^-1-exp(-L*0.25  )*(0.25  +L^-1))*exp(-rf5yos*(0.75+offset)) + ...
            0.25*exp(-L*(0.75+offset))*(exp(-L*0.25  )  +L^-1-exp(-L*0.25  )*(0.25  +L^-1))*exp(-rf5yos*(1.00+offset)) + ...
            0.25*exp(-L*(1.00+offset))*(exp(-L*0.25  )  +L^-1-exp(-L*0.25  )*(0.25  +L^-1))*exp(-rf5yos*(1.25+offset)) + ...
            0.25*exp(-L*(1.25+offset))*(exp(-L*0.25  )  +L^-1-exp(-L*0.25  )*(0.25  +L^-1))*exp(-rf5yos*(1.50+offset)) + ...
            0.25*exp(-L*(1.50+offset))*(exp(-L*0.25  )  +L^-1-exp(-L*0.25  )*(0.25  +L^-1))*exp(-rf5yos*(1.75+offset)) + ...
            0.25*exp(-L*(1.75+offset))*(exp(-L*0.25  )  +L^-1-exp(-L*0.25  )*(0.25  +L^-1))*exp(-rf5yos*(2.00+offset)) +...
            0.25*exp(-L*(2.00+offset))*(exp(-L*0.25  )  +L^-1-exp(-L*0.25  )*(0.25  +L^-1))*exp(-rf5yos*(2.25+offset)) + ...
            0.25*exp(-L*(2.25+offset))*(exp(-L*0.25  )  +L^-1-exp(-L*0.25  )*(0.25  +L^-1))*exp(-rf5yos*(2.50+offset)) + ...
            0.25*exp(-L*(2.50+offset))*(exp(-L*0.25  )  +L^-1-exp(-L*0.25  )*(0.25  +L^-1))*exp(-rf5yos*(2.75+offset)) + ...
            0.25*exp(-L*(2.75+offset))*(exp(-L*0.25  )  +L^-1-exp(-L*0.25  )*(0.25  +L^-1))*exp(-rf5yos*(3.00+offset)) +...                           
            0.25*exp(-L*(3.00+offset))*(exp(-L*0.25  )  +L^-1-exp(-L*0.25  )*(0.25  +L^-1))*exp(-rf5yos*(3.25+offset)) + ...
            0.25*exp(-L*(3.25+offset))*(exp(-L*0.25  )  +L^-1-exp(-L*0.25  )*(0.25  +L^-1))*exp(-rf5yos*(3.50+offset)) + ...
            0.25*exp(-L*(3.50+offset))*(exp(-L*0.25  )  +L^-1-exp(-L*0.25  )*(0.25  +L^-1))*exp(-rf5yos*(3.75+offset)) + ...
            0.25*exp(-L*(3.75+offset))*(exp(-L*0.25  )  +L^-1-exp(-L*0.25  )*(0.25  +L^-1))*exp(-rf5yos*(4.00+offset)) +...                    
            0.25*exp(-L*(4.00+offset))*(exp(-L*0.25  )  +L^-1-exp(-L*0.25  )*(0.25  +L^-1))*exp(-rf5yos*(4.25+offset)) + ...
            0.25*exp(-L*(4.25+offset))*(exp(-L*0.25  )  +L^-1-exp(-L*0.25  )*(0.25  +L^-1))*exp(-rf5yos*(4.50+offset)) + ...
            0.25*exp(-L*(4.50+offset))*(exp(-L*0.25  )  +L^-1-exp(-L*0.25  )*(0.25  +L^-1))*exp(-rf5yos*(4.75+offset)) + ...
            0.25*exp(-L*(4.75+offset))*(exp(-L*0.25  )  +L^-1-exp(-L*0.25  )*(0.25  +L^-1))*exp(-rf5yos*(5.00+offset)) ...                  
                ) -   spread        )   ;                                 
            
        x0=[0.0000001];
        [L,fval,exitflag_spread] = fzero(spread,x0);
        RNP=1-exp(-L*0.25); % L is the company's annualized hazard rate calculated from CDS
    
        % input vectors for interpolation
        x = strike;
        y = IV; 
       
        % generate two new strike prices around the traded strike prices
        a=size(x(:,1));
        b=a(1,1);
        for i = 1:b
            z1(i,1)=x(i,1)*0.999;
            z2(i,1)=x(i,1)*1.001; 
        end
        strikex=[z1;x;z2];
        strikex=sortrows(strikex);

        % calculate weight to interpolate the volatility smile
        totvol=sum(volume);
        fitw=[(volume/totvol)];
        
        % interpolate the volatility smile
        % natural smoothing cubic spline (Bliss & Panigirtzoglou, 2002)
        ft = fittype( 'smoothingspline' );
        opts = fitoptions( ft );
        opts.SmoothingParam = 0.01;
        opts.Weights = fitw;
        [fitresult, gof] = fit( x, y, ft, opts);
        IVnscs = feval(fitresult,strikex);
        clear volume totvol;         
        IVinter=IVnscs;   
        
        % kronecker the riskless rate and the stock price
        tens=ones(3,1);
        rfx=kron(rf90,tens);
        stockpricex=kron(stock_price,tens);
       
        % calculate call prices
        ttm=90/360;
        [Pr]=blsprice(stockpricex,strikex,rfx,ttm,IVinter);
       
        % calculate cdf at the traded strikes
        cdens=ones(3*b,1)*999;
        for i = 2:3:(3*b-1)
            cdens(i,1)=exp(rfx(i,1)*ttm)*( (Pr(i+1,1)-Pr(i-1,1))/(strikex(i+1,1)-strikex(i-1,1)) )+1;
        end
        Pr(cdens==999)=[];
        cdens(cdens==999)=[];
        % sort strike prices
        strike=sortrows(strike);
        ret=log(strike./stock_price);
        
        % eliminate when cdf is above 1 or below 0
        ret(cdens<0)=[];
        ret(cdens>1)=[]; 
        weight_opt_cds(cdens<0)=[];
        weight_opt_cds(cdens>1)=[];        
        weight_opt_nocds(cdens<0)=[];
        weight_opt_nocds(cdens>1)=[];        
        cdens(cdens<0)=[];
        cdens(cdens>1)=[];        
      
        % the weight calculation for estimation depends on whether the cds is included
        if cds_flag==1

            vweight=[weight_cds;weight_opt_cds];

            ret=[threshold;ret];
            cdens=[RNP;cdens];           
            [cdens,ret,vweight];      

            
        else
            vweight=weight_opt_nocds;
            [cdens,ret,vweight];      

        end
        
        % calculate the number of cdf data points
        data_size=size(cdens(:,1));
        obs=data_size(1,1);  
        
        % get the riskless rate on a quarterly basis
        riskfree = exp((log(1+rf90(1,1)))*0.25)-1;

        % estimate skew-t parameters
        options=optimset('Algorithm','interior-point','Display','off','Hessian','bfgs');

            % initial values for fmincon
            % the first is the volatility, the second is the degrees of freedom, the third is the shape parameter.
            x0=[0.40,   5.0, 0.100];
            lb=[0.05,   2.1,-0.995]; 
            ub=[1.25, 100.0, 0.995];
 
            % first estimating 10 sets of parameters from randomized starting values
            rng(1,'twister'); % set seed of random
            current_fval=1e9;
            error_var=1; % set error_var=1 by default for case when all 10 solutions to fmincon have volatility above 100%
            current_exitflag_rnd = 888; % to represent case when all 10 solutions to fmincon have volatility above 100%
            for i=1:10
                eps=[(rand(1,1)-0.5)*2*0.2, (rand(1,1)-0.5)*2*2, (rand(1,1)-0.5)*2*0.2];
                x0r=(x0+eps)';
                try        
                    [f, fval, exitflag_rnd] = fmincon(@(theta) sq_diff_sum(cdens,ret,obs,riskfree,vweight,theta), x0r,[],[],[],[],lb,ub,[],options) ;  

                    if f(1)>1
                        fval=2e9;
                    end
                    if fval<current_fval && exitflag_rnd>0
                        error_var=0; 
                        current_fval=fval;
                        current_exitflag_rnd=exitflag_rnd;
                        current_f=f;
                    end     
                    
                 catch err
                        error_var=1;
                        current_fval=999;
                        current_exitflag_rnd=999;
                        current_f=999;            
                 end
            end            
                
            % set parameter values to 999 (missing) by default           
            current_sqsum  = 999;
            current_vol    = 999;
            current_nu     = 999;
            current_lambda = 999;
            
            % if a set of estimates is available from fmincon, do a local grid search
            if error_var~=1
                
                pvol=round(current_f(1,1)*100)/100;
                pdof=round(current_f(2,1)*100)/100;
                pskw=round(current_f(3,1)*100)/100;

                lvol=max(pvol-0.05,0.05);
                ldof=max(pdof-0.1,2.1);
                lskw=max(pskw-0.05,-0.995);

                uvol=min(pvol+0.05,1.25);
                udof=min(pdof+0.1,100);
                uskw=min(pskw+0.05,0.995);
                    
                % create grid of paramter values to search over           
                grid_vol=[lvol:0.005:uvol]';
                grid_dof=[ldof:0.01:udof]';
                grid_skw=[lskw:0.005:uskw]';                
                [mesh1, mesh2, mesh3] = meshgrid(grid_vol, grid_dof, grid_skw);
                theta_grid = [mesh1(:)'; mesh2(:)'; mesh3(:)'];

                sq_diff_sum_val = sq_diff_sum(cdens,ret,obs,riskfree,vweight,theta_grid);
                [current_sqsum, minloc] = min(sq_diff_sum_val);
                current_vol    = theta_grid(1,minloc);
                current_nu     = theta_grid(2,minloc);
                current_lambda = theta_grid(3,minloc);   
            end

       results_matrix(loop_group,:) = [loop_group, exitflag_spread, current_exitflag_rnd, current_sqsum, current_vol, current_nu, current_lambda, datenum, permno];       
            
       
       % OPTIONAL: create figure to show estimated RND
       if 1==1
      
            close ALL;
            figure(1);

            logretvals = linspace(-5,5,1000);
            std_logretvals = logretvals / current_vol;
            pdfvals = skewtdis_pdf(std_logretvals, current_nu, current_lambda)/current_vol;

            plot(logretvals,pdfvals); 
            grid 'off'; 
            xlim([-1 1]);     
            xline(riskfree,'--r');
            title({strcat('Risk-neutral Distribution for permno=',num2str(permno),' on datenum=',num2str(datenum)), ...
                strcat(...
                'vol=',num2str(current_vol,'%5.3f'),', ',...
                ' DOF=',num2str(current_nu,'%5.3f'),', ',...
                ' lambda=',num2str(current_lambda))});                
            %title({strcat('loop group=',num2str(loop_group)),'line2'});
            xlabel('Log Return');
            ylabel('Density');                 

            fname = strcat('figure_rnd_loop_group',num2str(loop_group));
            saveas(1,strcat(fname),'png');  
            
       end       
       
       
    catch err
      err; 
      results_matrix(loop_group,:) = [loop_group, NaN, NaN, NaN, NaN, NaN, NaN, datenum, permno];    
    end
 
end

% record ending time
time_end = toc(time_start);
disp(strcat('total minutes=',num2str(time_end/60)));
disp(strcat('total hours=',num2str(time_end/60/60)));

% save final matrix
filename = 'results_table.xlsx';
varnames = {'loop_group', 'exitflag_spread', 'current_exitflag_rnd', 'current_sqsum', 'current_vol', 'current_nu', 'current_lambda', 'datenum', 'permno'};
results_table = array2table(results_matrix, 'VariableNames', varnames);
writetable(results_table, filename,'Sheet',1);

